// content-script.js
console.log("Content script injected");